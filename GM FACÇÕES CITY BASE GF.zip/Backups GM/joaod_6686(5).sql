-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Tempo de geração: 17/08/2022 às 09:02
-- Versão do servidor: 10.5.10-MariaDB
-- Versão do PHP: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `joaod_6686`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `banidos`
--

CREATE TABLE IF NOT EXISTS `banidos` (
  `AccountID` int(11) NOT NULL,
  `Nick` varchar(25) NOT NULL,
  `IP` varchar(16) NOT NULL,
  `Admin` varchar(25) NOT NULL,
  `Motivo` varchar(255) NOT NULL,
  `Data` varchar(255) NOT NULL,
  `TimerBan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Fazendo dump de dados para tabela `banidos`
--

INSERT INTO `banidos` (`AccountID`, `Nick`, `IP`, `Admin`, `Motivo`, `Data`, `TimerBan`) VALUES
(135, 'ManoBill', '45.230.68.110', 'KBmetficha', 'fdp', '1660596889', 1746910489);

-- --------------------------------------------------------

--
-- Estrutura para tabela `code_coins`
--

CREATE TABLE IF NOT EXISTS `code_coins` (
  `Code` int(255) NOT NULL,
  `Coins` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura para tabela `contas`
--

CREATE TABLE IF NOT EXISTS `contas` (
  `AccountID` int(11) NOT NULL,
  `Nick` varchar(25) NOT NULL,
  `Nome` varchar(255) NOT NULL,
  `Salt` varchar(65) NOT NULL,
  `Senha` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Funcao` varchar(255) DEFAULT NULL,
  `ReasonPrison` varchar(64) DEFAULT NULL,
  `Online` int(11) DEFAULT NULL,
  `Score` int(11) DEFAULT NULL,
  `Morro_ID` int(11) DEFAULT NULL,
  `Admin` int(11) DEFAULT NULL,
  `Police` int(11) DEFAULT NULL,
  `Exercito` int(11) DEFAULT NULL,
  `Bope` int(11) DEFAULT NULL,
  `Army` int(11) DEFAULT NULL,
  `Trafico` int(11) DEFAULT NULL,
  `Matuto` int(11) DEFAULT NULL,
  `Helper` int(11) DEFAULT NULL,
  `Reporter` int(11) DEFAULT NULL,
  `DJ` int(11) DEFAULT NULL,
  `Skin` int(11) DEFAULT NULL,
  `Exp` int(11) DEFAULT NULL,
  `Payday` int(11) DEFAULT NULL,
  `Money` int(11) DEFAULT NULL,
  `Coins` int(11) DEFAULT NULL,
  `Abatimento` int(11) DEFAULT NULL,
  `AB_Trafico` int(11) DEFAULT NULL,
  `Drogas_A` int(11) DEFAULT NULL,
  `Matou` int(11) DEFAULT NULL,
  `Morreu` int(11) DEFAULT NULL,
  `Win_Duel` int(11) DEFAULT NULL,
  `Lose_Duel` int(11) DEFAULT NULL,
  `Avaliar_No` int(11) DEFAULT NULL,
  `Avaliar_Yes` int(11) DEFAULT NULL,
  `Reports` int(11) DEFAULT NULL,
  `Procurado` int(11) DEFAULT NULL,
  `LastNick` int(11) DEFAULT NULL,
  `LastLogin` int(11) DEFAULT NULL,
  `Tempo_Jogo` int(11) DEFAULT NULL,
  `DateRegister` int(11) DEFAULT NULL,
  `Preso` int(11) DEFAULT NULL,
  `TimerPrison` int(11) DEFAULT NULL,
  `Punished` int(11) DEFAULT NULL,
  `privacyMessage` int(11) DEFAULT NULL,
  `bodyWeapon` int(11) DEFAULT NULL,
  `PrivacyIR` int(11) DEFAULT NULL,
  `PrivacyTR` int(11) DEFAULT NULL,
  `ReceivedVip` int(11) DEFAULT NULL,
  `Terms` int(11) DEFAULT NULL,
  `TimeGiveVip` int(11) DEFAULT NULL,
  `Character0` int(11) DEFAULT NULL,
  `Character0Timestamp` int(11) DEFAULT NULL,
  `Slot0` int(11) DEFAULT NULL,
  `Slot0Quant` int(11) DEFAULT NULL,
  `Slot0Timestamp` int(11) DEFAULT NULL,
  `Character1` int(11) DEFAULT NULL,
  `Character1Timestamp` int(11) DEFAULT NULL,
  `Slot1` int(11) DEFAULT NULL,
  `Slot1Quant` int(11) DEFAULT NULL,
  `Slot1Timestamp` int(11) DEFAULT NULL,
  `Character2` int(11) DEFAULT NULL,
  `Character2Timestamp` int(11) DEFAULT NULL,
  `Slot2` int(11) DEFAULT NULL,
  `Slot2Quant` int(11) DEFAULT NULL,
  `Slot2Timestamp` int(11) DEFAULT NULL,
  `Character3` int(11) DEFAULT NULL,
  `Character3Timestamp` int(11) DEFAULT NULL,
  `Slot3` int(11) DEFAULT NULL,
  `Slot3Quant` int(11) DEFAULT NULL,
  `Slot3Timestamp` int(11) DEFAULT NULL,
  `Character4` int(11) DEFAULT NULL,
  `Character4Timestamp` int(11) DEFAULT NULL,
  `Slot4` int(11) DEFAULT NULL,
  `Slot4Quant` int(11) DEFAULT NULL,
  `Slot4Timestamp` int(11) DEFAULT NULL,
  `Character5` int(11) DEFAULT NULL,
  `Character5Timestamp` int(11) DEFAULT NULL,
  `Slot5` int(11) DEFAULT NULL,
  `Slot5Quant` int(11) DEFAULT NULL,
  `Slot5Timestamp` int(11) DEFAULT NULL,
  `Character6` int(11) DEFAULT NULL,
  `Character6Timestamp` int(11) DEFAULT NULL,
  `Slot6` int(11) DEFAULT NULL,
  `Slot6Quant` int(11) DEFAULT NULL,
  `Slot6Timestamp` int(11) DEFAULT NULL,
  `Character7` int(11) DEFAULT NULL,
  `Character7Timestamp` int(11) DEFAULT NULL,
  `Slot7` int(11) DEFAULT NULL,
  `Slot7Quant` int(11) DEFAULT NULL,
  `Slot7Timestamp` int(11) DEFAULT NULL,
  `Character8` int(11) DEFAULT NULL,
  `Character8Timestamp` int(11) DEFAULT NULL,
  `Slot8` int(11) DEFAULT NULL,
  `Slot8Quant` int(11) DEFAULT NULL,
  `Slot8Timestamp` int(11) DEFAULT NULL,
  `Character9` int(11) DEFAULT NULL,
  `Character9Timestamp` int(11) DEFAULT NULL,
  `Slot9` int(11) DEFAULT NULL,
  `Slot9Quant` int(11) DEFAULT NULL,
  `Slot9Timestamp` int(11) DEFAULT NULL,
  `Character10` int(11) DEFAULT NULL,
  `Character10Timestamp` int(11) DEFAULT NULL,
  `Slot10` int(11) DEFAULT NULL,
  `Slot10Quant` int(11) DEFAULT NULL,
  `Slot10Timestamp` int(11) DEFAULT NULL,
  `Character11` int(11) DEFAULT NULL,
  `Character11Timestamp` int(11) DEFAULT NULL,
  `Slot11` int(11) DEFAULT NULL,
  `Slot11Quant` int(11) DEFAULT NULL,
  `Slot11Timestamp` int(11) DEFAULT NULL,
  `Character12` int(11) DEFAULT NULL,
  `Character12Timestamp` int(11) DEFAULT NULL,
  `Slot12` int(11) DEFAULT NULL,
  `Slot12Quant` int(11) DEFAULT NULL,
  `Slot12Timestamp` int(11) DEFAULT NULL,
  `Character13` int(11) DEFAULT NULL,
  `Character13Timestamp` int(11) DEFAULT NULL,
  `Slot13` int(11) DEFAULT NULL,
  `Slot13Quant` int(11) DEFAULT NULL,
  `Slot13Timestamp` int(11) DEFAULT NULL,
  `Character14` int(11) DEFAULT NULL,
  `Character14Timestamp` int(11) DEFAULT NULL,
  `Slot14` int(11) DEFAULT NULL,
  `Slot14Quant` int(11) DEFAULT NULL,
  `Slot14Timestamp` int(11) DEFAULT NULL,
  `Character15` int(11) DEFAULT NULL,
  `Character15Timestamp` int(11) DEFAULT NULL,
  `Slot15` int(11) DEFAULT NULL,
  `Slot15Quant` int(11) DEFAULT NULL,
  `Slot15Timestamp` int(11) DEFAULT NULL,
  `Character16` int(11) DEFAULT NULL,
  `Character16Timestamp` int(11) DEFAULT NULL,
  `Slot16` int(11) DEFAULT NULL,
  `Slot16Quant` int(11) DEFAULT NULL,
  `Slot16Timestamp` int(11) DEFAULT NULL,
  `Character17` int(11) DEFAULT NULL,
  `Character17Timestamp` int(11) DEFAULT NULL,
  `Slot17` int(11) DEFAULT NULL,
  `Slot17Quant` int(11) DEFAULT NULL,
  `Slot17Timestamp` int(11) DEFAULT NULL,
  `Character18` int(11) DEFAULT NULL,
  `Character18Timestamp` int(11) DEFAULT NULL,
  `Slot18` int(11) DEFAULT NULL,
  `Slot18Quant` int(11) DEFAULT NULL,
  `Slot18Timestamp` int(11) DEFAULT NULL,
  `Character19` int(11) DEFAULT NULL,
  `Character19Timestamp` int(11) DEFAULT NULL,
  `Slot19` int(11) DEFAULT NULL,
  `Slot19Quant` int(11) DEFAULT NULL,
  `Slot19Timestamp` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=227 DEFAULT CHARSET=utf8mb4;

--
-- Fazendo dump de dados para tabela `contas`
--
-- --------------------------------------------------------

--
-- Estrutura para tabela `favelas`
--

CREATE TABLE IF NOT EXISTS `favelas` (
  `ID_Morro` int(25) NOT NULL,
  `Nome` varchar(255) NOT NULL,
  `Armas` int(11) NOT NULL,
  `Maconha` int(11) NOT NULL,
  `Cocaina` int(11) NOT NULL,
  `Dinheiro` int(11) NOT NULL,
  `Dominio` varchar(255) NOT NULL,
  `Punishment` int(11) NOT NULL,
  `TimePunishment` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Fazendo dump de dados para tabela `favelas`
--

INSERT INTO `favelas` (`ID_Morro`, `Nome`, `Armas`, `Maconha`, `Cocaina`, `Dinheiro`, `Dominio`, `Punishment`, `TimePunishment`) VALUES
(0, 'Complexo do Alemão', 0, 0, 0, 77783, '2', 0, '0'),
(1, 'Parque União', 0, 0, 0, 50000, '0', 0, '0'),
(2, 'Sabão', 19, 0, 0, 0, '0', 0, '0'),
(3, 'Jardim Catarina', 0, 0, 0, 50000, '0', 0, '0'),
(4, 'Jardim Novo', 19, 0, 0, 0, '0', 0, '0'),
(5, 'Morro do 77', 6, 0, 0, 50000, '0', 0, '0'),
(6, 'Vila Vintem', 14, 0, 0, 50000, '0', 0, '0'),
(7, 'Conjuntao', 13, 0, 0, 0, '0', 0, '0'),
(8, 'Acari', 0, 0, 0, 0, '0', 0, '0'),
(9, 'Cidade Alta', 99, 200, 0, 0, '0', 0, '0'),
(10, 'Vigario Geral', 9, 0, 0, 0, '0', 0, '0'),
(11, 'Vila do João', 3, 0, 0, 60628, '0', 0, '0'),
(12, 'Antares', 6, 0, 0, 50000, '0', 0, '0'),
(13, 'Rodo', 5, 0, 0, 50000, '0', 0, '0'),
(14, 'Morador', 20, 0, 0, 0, '0', 0, '0');

-- --------------------------------------------------------

--
-- Estrutura para tabela `historico`
--

CREATE TABLE IF NOT EXISTS `historico` (
  `accountid` int(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `date` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Fazendo dump de dados para tabela `historico`
--

INSERT INTO `historico` (`accountid`, `name`, `date`) VALUES
(64, 'NiELrlQ[LDH]', 1660525951),
(75, 'FIELdoFALL.PH[GM]', 1660526552),
(38, 'NevesrLQ7.CRIA[SGM]', 1660526756),
(28, 'DjGS', 1660527516),
(37, 'KB.DONO', 1660530322),
(37, 'PAIZAO', 1660570786),
(92, 'ManoHulk.77.DM', 1660571366),
(109, 'RN.CPX', 1660577182),
(116, 'balatrem', 1660580121),
(33, 'GORDAO.CPX[FRT]', 1660587842),
(105, '[ADMT]FTF[MTX]', 1660588143),
(57, 'BabyMal22.CPX', 1660589715),
(131, 'mete.rebolando', 1660591949),
(63, 'SC.MLC.[ADM]', 1660597977),
(121, 'DUDU.CPX[DM]', 1660599187),
(36, 'ZANGADO', 1660599493),
(76, 'AstroXit', 1660600296),
(143, 'DUbalaoTROIA2', 1660605052),
(97, 'baeco', 1660607759),
(140, '5B.JC[FRT]', 1660610184),
(140, '5B.JC[ADM]', 1660610339),
(91, 'LAFON157.[LDF]', 1660612205),
(118, '[2BTL]CHEFINHO[ADMT]', 1660612832),
(143, 'REidoPiX.ACR', 1660615480),
(173, 'PandaTD3.ADM', 1660621742),
(132, 'LOIRINHO.PU', 1660622291),
(92, 'ManoHulk.ADMT', 1660625862),
(180, 'anaclara', 1660636888),
(165, 'RD.NOVO', 1660648849),
(77, 'Jogador57mtx.3P[LDF]', 1660650010),
(58, 'MACACO.CPX[DM]', 1660653743),
(192, 'Jhrlk.cda[VPR]', 1660667136),
(186, 'DAGUERRA.VJ', 1660670411),
(41, 'MATUEdoFALL[LDF]', 1660670671),
(198, 'mengo', 1660677128),
(199, 'URUBU.PH[GRT]', 1660680287),
(140, '5B.JC[ADMT]', 1660682261),
(140, '5B.JC[FRT]', 1660694164),
(88, 'SementinhaRlq', 1660704111),
(141, 'DUDUZIN.SB[DM]', 1660705463),
(140, '[PMRJ].5B[PM]', 1660710941);

-- --------------------------------------------------------

--
-- Estrutura para tabela `server`
--

CREATE TABLE IF NOT EXISTS `server` (
  `id` int(11) NOT NULL,
  `hostname1` varchar(50) DEFAULT NULL,
  `hostname2` varchar(50) DEFAULT NULL,
  `painel` varchar(50) DEFAULT NULL,
  `antifake` varchar(50) DEFAULT NULL,
  `radio` varchar(100) NOT NULL,
  `vipDays1` int(255) DEFAULT NULL,
  `vipCash1` int(255) DEFAULT NULL,
  `vipName1` varchar(255) DEFAULT NULL,
  `vipDays2` int(255) DEFAULT NULL,
  `vipCash2` int(255) DEFAULT NULL,
  `vipName2` varchar(255) DEFAULT NULL,
  `vipDays3` int(255) DEFAULT NULL,
  `vipCash3` int(255) DEFAULT NULL,
  `vipName3` varchar(255) DEFAULT NULL,
  `vipDays4` int(255) DEFAULT NULL,
  `vipCash4` int(255) DEFAULT NULL,
  `vipName4` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Fazendo dump de dados para tabela `server`
--

INSERT INTO `server` (`id`, `hostname1`, `hostname2`, `painel`, `antifake`, `radio`, `vipDays1`, `vipCash1`, `vipName1`, `vipDays2`, `vipCash2`, `vipName2`, `vipDays3`, `vipCash3`, `vipName3`, `vipDays4`, `vipCash4`, `vipName4`) VALUES
(1, 'GTA FACCOES CITY RJ [PC/Android]', 'GTA FACCOES CITY RJ [PC/Android]', 'fcrreina2204@', 'fcreina', '1395271', 10, 200, 'vip 1', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `vips`
--

CREATE TABLE IF NOT EXISTS `vips` (
  `AccountID` int(64) DEFAULT NULL,
  `Nick` varchar(255) NOT NULL,
  `Tipo_Vip` varchar(255) DEFAULT NULL,
  `Timer_Vip` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Fazendo dump de dados para tabela `vips`
--

INSERT INTO `vips` (`AccountID`, `Nick`, `Tipo_Vip`, `Timer_Vip`) VALUES
(83, 'Salvador.KM2[DM]', '', '1660530017'),
(83, 'Salvador.KM2[DM]', '', '1660530049'),
(50, 'KAUAZIN.PH[GRT]', 'Ganhado', '1660658662'),
(100, 'SILVA.ACR[FRT]', 'Ganhado', '1660663102'),
(106, 'JD.VJ[DM]', 'Ganhado', '1660669300'),
(47, '5B.VJ[FRT]', 'Ganhado', '1660674448'),
(72, '[2BTL]Coroa.CRNL', 'Ganhado', '1660685147'),
(108, 'PHTREM', 'Ganhado', '1660701661'),
(50, 'KAUAZIN.PH[GRT]', '', '1660658662'),
(92, 'ManoHulk.BRACO', '', '1660626570'),
(37, 'KBmetficha', 'Ganhado', '1660733445'),
(77, 'Jogador57mtx.ANT[LDF', 'Ganhado', '1660735475'),
(172, 'gui.pu', 'Ganhado', '1660741325'),
(58, 'KN.CPX[DM]', 'Ganhado', '1660743161'),
(40, 'Flax.GM', 'Ganhado', '1660745335'),
(140, '[BOPE].5B[SGT]', 'Ganhado', '1660756976'),
(41, 'MATUEdoFALL[ADMA]', 'Ganhado', '1660767329'),
(199, '[BOPE]Urubu7Rlq.LD', 'Ganhado', '1660769643'),
(69, 'GN.TD3[ADMA]', 'Ganhado', '1660774670'),
(87, '[BOPE]FILHOTE.CMDT', 'Ganhado', '1660777057'),
(38, 'NevesrLQ7.CRIA[GM]', 'Ganhado', '1660777516'),
(139, 'madrugadaoBzG', 'Ganhado', '1660779526'),
(189, 'JHON.ANT.DM', 'Ganhado', '1660730363'),
(88, '[BOPE]Sementinha.CRN', 'Ganhado', '1660790009'),
(218, '[BOPE].JOTAPE.SLB', 'Ganhado', '1660792726'),
(31, 'LcReliquia[LD]', 'Ganhado', '1660795345'),
(31, 'LcReliquia[LD]', 'Setado', '1661227345'),
(28, 'DjGS.DONO', 'Setado', '1661144966'),
(73, 'Rnzin.ADMT', 'Setado', '1661144976'),
(28, 'DjGS.DONO', 'Setado', '1661231366'),
(31, 'LcReliquia[LD]', 'Setado', '1661313745'),
(73, 'Rnzin.ADMT', 'Setado', '1661231376'),
(31, 'LcReliquia[LD]', 'Setado', '1663041745'),
(0, 'GS.GORDIN', 'Registro', '1662443241');

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `banidos`
--
ALTER TABLE `banidos`
  ADD PRIMARY KEY (`AccountID`);

--
-- Índices de tabela `contas`
--
ALTER TABLE `contas`
  ADD PRIMARY KEY (`AccountID`);

--
-- Índices de tabela `favelas`
--
ALTER TABLE `favelas`
  ADD PRIMARY KEY (`ID_Morro`);

--
-- Índices de tabela `server`
--
ALTER TABLE `server`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `vips`
--
ALTER TABLE `vips`
  ADD KEY `AccountID` (`AccountID`),
  ADD KEY `AccountID_2` (`AccountID`),
  ADD KEY `AccountID_3` (`AccountID`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `contas`
--
ALTER TABLE `contas`
  MODIFY `AccountID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=227;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
